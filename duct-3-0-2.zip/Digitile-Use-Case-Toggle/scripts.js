jQuery(document).ready(function($) {
    let owl = jQuery('.owl-carousel-1');
    owl.on('changed.owl.carousel', function(e) {
        $('.lt-tab1 .url').removeClass('active');
        $($('.lt-tab1 .url')[e.item.index]).addClass('active');
    });
    let owl2 = jQuery('.owl-carousel-2');
    owl2.on('changed.owl.carousel', function(e) {
        $('.lt-tab2 .url').removeClass('active');
        $($('.lt-tab2 .url')[e.item.index]).addClass('active');
    });
    $('.left-toggle').click(function() {
        let id = $(this).attr('id');
        $('.duct-toggle').removeClass('active');
        $('.tabs').removeClass('active');
        $('#' + id + 'C').addClass('active');
        $('.tabs.' + id).addClass('active');
        $('.left-toggle').removeClass('active');
        $(this).addClass('active');

        let DIheight = 450;
        
        if ($('.people-familiar').hasClass('active')) {
            $('.people-familiar').css('margin-top', '0px');
        } else {
            if ($(window).width() < 600) {
                DIheight = jQuery('.mobile-image')[0].offsetHeight;
            } else if ($(window).width() > 600 && $(window).width() < 993) {
                DIheight = jQuery('.tablet-image')[0].offsetHeight;
            } else {
                DIheight = jQuery('.desktop-image')[0].offsetHeight;
            }
            let pullUpSize = parseInt(DIheight);
            $('.people-familiar').css('margin-top', "-" + pullUpSize + "px");
        }
    })
    $('.owl-carousel-1').owlCarousel({
        items: 1,
        loop: false,
        center: true,
        margin: 10,
        URLhashListener: true,
        autoplayHoverPause: true,
        startPosition: '#pf-tab1C'
    });
    $('.owl-carousel-2').owlCarousel({
        items: 1,
        loop: false,
        center: true,
        margin: 10,
        URLhashListener: true,
        autoplayHoverPause: true,
        startPosition: '#puf-tab1C'
    });
    jQuery(".uct-card-button").click(function(e) {
        e.preventDefault();
        jQuery(this).addClass("loading");
        page = jQuery(this).attr("id");
        skip = jQuery('section.uct-cards').attr("skip");
        jQuery(this).attr("id", parseInt(page) + 1);
        jQuery.ajax({
            type: "get",
            url: uct.ajaxurl,
            data: {
                action: "load_uct_cards",
                page: page,
                skip: skip,
            },
            dataType: 'JSON',
            success: function(response) {
                if (response) {
                    jQuery(".uct-cards").append(response.cards);
                    if (!response.hasMore) {
                        jQuery('.uct-card-button').addClass("hidden");
                    }
                }
                jQuery('.uct-card-button').removeClass("loading");
            },
            error: function() {
                jQuery('.uct-card-button').removeClass("loading");
                alert("Failed to load more cards");
            }
        });
    });
    document.querySelector('.custom-select-wrapper').addEventListener('click', function() {
        this.querySelector('.custom-select').classList.toggle('open');
    })
    for (const option of document.querySelectorAll(".custom-option")) {
        option.addEventListener('click', function() {
            if (!this.classList.contains('selected')) {
                this.parentNode.querySelector('.custom-option.selected').classList.remove('selected');
                this.classList.add('selected');
                this.closest('.custom-select').querySelector('.custom-select__trigger span').textContent = this.textContent;
                let id = $(this).attr('id');
                $('.duct-toggle').removeClass('active');
                $('#' + id + 'C').addClass('active');
        $('.tabs').removeClass('active');
        $('.tabs.' + id).addClass('active');
        let DIheight = 450;
        
        if ($('.people-familiar').hasClass('active')) {
            $('.people-familiar').css('margin-top', '0px');
        } else {
            if ($(window).width() < 600) {
                DIheight = jQuery('.mobile-image')[0].offsetHeight;
            } else if ($(window).width() > 600 && $(window).width() < 993) {
                DIheight = jQuery('.tablet-image')[0].offsetHeight;
            } else {
                DIheight = jQuery('.desktop-image')[0].offsetHeight;
            }
            let pullUpSize = parseInt(DIheight);
            $('.people-familiar').css('margin-top', "-" + pullUpSize + "px");
        }
            }
        })
    }
    let imgHeight = 450;
    if ($(window).width() < 600) {
        imgHeight = jQuery('.mobile-image')[0].offsetHeight;
    } else if ($(window).width() > 600 && $(window).width() < 993) {
        imgHeight = jQuery('.tablet-image')[0].offsetHeight;
    } else {
        imgHeight = jQuery('.desktop-image')[0].offsetHeight;
    }
    jQuery('.carousel-wrapper').css('height', parseInt(imgHeight) + 50 + 'px');
});