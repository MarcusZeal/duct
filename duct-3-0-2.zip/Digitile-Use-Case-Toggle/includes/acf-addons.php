<?php

/**
 * ACF Functions
 */

function uct_acf_settings_path($path)
{
    $path = plugin_dir_path(__FILE__) . '../acf/';
    return $path;
}
function uct_acf_settings_dir($path)
{
    $dir = plugin_dir_url(__FILE__) . '../acf/';
    return $dir;
}
function uct_acf_json_save_point($path)
{
    $path = plugin_dir_path(__FILE__) . '../acf-json/';
    return $path;
}
function uct_stop_acf_update_notifications($value)
{
    unset($value->response[plugin_dir_path(__FILE__) . '../acf/acf.php']);
    return $value;
}
function uct_acf_json_load_point($paths)
{
    $paths[] = plugin_dir_path(__FILE__) . '../acf-json-load';
    return $paths;
}
