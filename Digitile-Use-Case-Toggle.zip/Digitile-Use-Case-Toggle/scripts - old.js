jQuery(document).ready(function($) {
    // Duct Tab 1
    $('div#lt-tab1C #tabs li:not(:first)').addClass('inactive');
    $('div#lt-tab1C .tag-container:not(:first) img').css('left', '150%');
    $('div#lt-tab1C #tabs li').click(function() {
        var t = $(this).attr('id');
        var y = $('#' + t + 'C');
        var img = y.find('img');
        var ac = $('div#lt-tab1C .tag-container.active');
        var activeimg = ac.find('img');
        if ($(this).hasClass('inactive')) { //this is the start of our condition 
            $('div#lt-tab1C #tabs li').addClass('inactive');
            $(this).removeClass('inactive');
            $(activeimg).animate({
                left: "-150%"
                }, 500, function() {
                // Animation complete.
                });
            $('div#lt-tab1C .tag-container').removeClass('active');
            $(y).show();
            $(y).addClass('active');
            $(img).animate({
                left: "30px"
                }, 500, function() {
                // Animation complete.
                });
        }
    });
    //Duct Tab 2
    $('div#lt-tab2C #tabs li:not(:first)').addClass('inactive');
    $('div#lt-tab2C .tag-container:not(:first) img').css('left', '150%');
    $('div#lt-tab2C #tabs li').click(function() {
        var t = $(this).attr('id');
        var y = $('#' + t + 'C');
        var img = y.find('img');
        var ac = $('div#lt-tab2C .tag-container.active');
        var activeimg = ac.find('img');
        if ($(this).hasClass('inactive')) { //this is the start of our condition 
            $('div#lt-tab2C #tabs li').addClass('inactive');
            $(this).removeClass('inactive');
            $(activeimg).animate({
                left: "-150%"
                }, 500, function() {
                // Animation complete.
                });
            $('div#lt-tab2C .tag-container').removeClass('active');
            $(y).show();
            $(y).addClass('active');
            $(img).animate({
                left: "30px"
                }, 500, function() {
                // Animation complete.
                });

        }
    });
    // Duct Tab Between Tabs
    $('.left-toggles .left-toggle:not(:first)').addClass('inactive');
    $('.duct-toggle').hide();
    $('.duct-toggle:first').show();
    $('.left-toggles .left-toggle').click(function() {
        var t = $(this).attr('id');
        var y = $('#' + t + 'C');
        var img = y.find('img');
        var ac = $('.tag-container.active');
        var activeimg = ac.find('img');

        
        if ($(this).hasClass('inactive')) { //this is the start of our condition 
            $('.left-toggles .left-toggle').addClass('inactive');
            $(this).removeClass('inactive');
            $('.duct-toggle').hide();

            $(y).show();

        }
    });
    jQuery(".uct-card-button").click(function(e) {
        e.preventDefault();
        jQuery(this).addClass("loading");
        page = jQuery(this).attr("id");
        skip = jQuery('section.uct-cards').attr("skip");
        jQuery(this).attr("id", parseInt(page) + 1);
        jQuery.ajax({
            type: "get",
            url: uct.ajaxurl,
            data: {
                action: "load_uct_cards",
                page: page,
                skip: skip,
            },
            dataType: 'JSON',
            success: function(response) {
                if (response) {
                    jQuery(".uct-cards").append(response.cards);
                    if (!response.hasMore) {
                        jQuery('.uct-card-button').addClass("hidden");
                    }
                }
                jQuery('.uct-card-button').removeClass("loading");
            },
            error: function() {
                jQuery('.uct-card-button').removeClass("loading");
                alert("Failed to load more cards");
            }
        });
    });
});