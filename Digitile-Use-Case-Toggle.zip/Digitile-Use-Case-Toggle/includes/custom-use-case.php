<?php

    // ACF DUCT (Digitile Use Case Toggle)
    function use_case_query($atts, $content)    {

        ob_start();

        extract(shortcode_atts(array( // a few default values
            'id' => null,
            'posts_per_page' => '1',
            'caller_get_posts' => 1
        ) , $atts));

        $args = array(
            'post_type' => 'use_case',
            'numberposts' => - 1
        );

        if ($atts['id'])
        {
            $args['p'] = $atts['id'];
        }

        global $post;
        $posts = new WP_Query($args);
        $output = '';

        if ($posts->have_posts()) while ($posts->have_posts()):
            $posts->the_post();

    ?>



	<div class="duct-wrapper title-text-wrap">
		<div class="spacer">		</div>
		<div class="right-toggles title-text">
			 <?php the_title( '<h3>', '</h3>' ); ?>
		</div>
	</div>


    <div class="duct-wrapper">

    <div class="left-toggles">
        <div class="tags-for-people-familiar-toggle left-toggle" id="lt-tab1">
            <h3>Tags for People Familiar</h3>
            <p>Create a tagging scheme for people on your team, clients, or any stakeholder that’s familiar with tags</p>
        </div>
        <div class="tags-for-people-unfamiliar-toggle left-toggle"  id="lt-tab2">
            <h3>Tags for People Unfamiliar</h3>
            <p>Create a tagging scheme for people that haven’t joined the team yet, external stakeholders, or across departments</p>
        </div>
    </div>

    <div class="right-toggles">

    <?php if (have_rows('tags_for_people_familiar')): //parent group field
                while (have_rows('tags_for_people_familiar')):
                    the_row(); ?>

            <div class="people-familiar duct-toggle active" id="lt-tab1C"> 
                
            
    <ul id="tabs" class="navbar">
        <li class="tag-nav" id="pf-tab1" data-hash="pf-tab1C">Content Tag</li>
        <li class="tag-nav" id="pf-tab2" data-hash="pf-tab2C">Category Tag</li>
        <li class="tag-nav" id="pf-tab3" data-hash="pf-tab3C">Workflow Tag</li>
        <li class="tag-nav" id="pf-tab4" data-hash="pf-tab4C">Stakeholder Tag</li>
    </ul>

    <div class="slide-tab-container">

                <div class="content-tag tag-container" id="pf-tab1C">
                <?php if (have_rows('content_tag')): //child group field
                        while (have_rows('content_tag')):
                            the_row(); ?>             
                        
                            <div class="desktop-image">
                                    <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                        <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                            <div class="tablet-image">
                                    <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                        <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                            <div class="mobile-image">
                                    <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                        <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                    <?php
                        endwhile; ?>
                <?php
                    endif; ?>
                </div><!-- .content-tag -->

                <div class="category-tag tag-container "id="pf-tab2C">
                <?php if (have_rows('category_tag')): //child group field
                        while (have_rows('category_tag')):
                            the_row(); ?>             
                        
                            <div class="desktop-image  ">
                                    <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                        <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>
                            
                            <div class="tablet-image  ">
                                    <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                        <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                            <div class="mobile-image  ">
                                    <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                        <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                    <?php
                        endwhile; ?>
                <?php
                    endif; ?>
                </div><!-- .category-tag -->

                <div class="workflow-tag tag-container "id="pf-tab3C">
                <?php if (have_rows('workflow_tag')): //child group field
                        while (have_rows('workflow_tag')):
                            the_row(); ?>             
                        
                            <div class="desktop-image  ">
                                    <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                        <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>
                            
                            <div class="tablet-image  ">
                                    <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                        <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                            <div class="mobile-image  ">
                                    <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                        <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                    <?php
                        endwhile; ?>
                <?php
                    endif; ?>
                </div><!-- .workflow-tag -->

                <div class="stakeholder-tag tag-container "id="pf-tab4C">
                <?php if (have_rows('stakeholder_tag')): //child group field
                        while (have_rows('stakeholder_tag')):
                            the_row(); ?>             
                        
                            <div class="desktop-image  ">
                                    <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                        <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>
                            
                            <div class="tablet-image  ">
                                    <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                        <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                            <div class="mobile-image  ">
                                    <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                        <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                    <?php
                            endif; ?>
                            </div>

                    <?php
                        endwhile; ?>
                <?php
                    endif; ?>
                </div><!-- .workflow-tag -->                   
            </div> <!-- .people-familiar.duct-toggle --> 

        <?php
                endwhile; ?>
    <?php
            endif; ?>

   </div>

    <?php if (have_rows('tags_for_people_unfamiliar')): //parent group field
                while (have_rows('tags_for_people_unfamiliar')):
                    the_row(); ?>



    <div class="people-unfamiliar duct-toggle  " id="lt-tab2C">      
            
      
    <ul id="tabs"  class="navbar">
        <li class="tag-nav" id="puf-tab1" data-hash="puf-tab1C">Content Tag</li>
        <li class="tag-nav" id="puf-tab2" data-hash="puf-tab2C">Category Tag</li>
        <li class="tag-nav" id="puf-tab3" data-hash="puf-tab3C">Workflow Tag</li>
        <li class="tag-nav" id="puf-tab4" data-hash="puf-tab4C">Stakeholder Tag</li>
    </ul>
    
    <div class="slide-tab-container">

            <div class="content-tag tag-container" id="puf-tab1C">
                <?php if (have_rows('content_tag')): //child group field
                        while (have_rows('content_tag')):
                            the_row(); ?>             
                        
                        <div class="desktop-image  ">
                                <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                    <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                        <div class="tablet-image  ">
                                <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                    <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                        <div class="mobile-image  ">
                                <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                    <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                <?php
                        endwhile; ?>
            <?php
                    endif; ?>
            </div><!-- .content-tag -->

            <div class="category-tag tag-container "id="puf-tab2C">
                <?php if (have_rows('category_tag')): //child group field
                        while (have_rows('category_tag')):
                            the_row(); ?>             
                        
                        <div class="desktop-image  ">
                                <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                    <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>
                        
                        <div class="tablet-image  ">
                                <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                    <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                        <div class="mobile-image  ">
                                <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                    <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                <?php
                        endwhile; ?>
            <?php
                    endif; ?>
            </div><!-- .category-tag -->

            <div class="workflow-tag tag-container "id="puf-tab3C">
                <?php if (have_rows('workflow_tag')): //child group field
                        while (have_rows('workflow_tag')):
                            the_row(); ?>             
                        
                        <div class="desktop-image  ">
                                <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                    <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>
                        
                        <div class="tablet-image  ">
                                <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                    <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                        <div class="mobile-image  ">
                                <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                    <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                <?php
                        endwhile; ?>
            <?php
                    endif; ?>
            </div><!-- .workflow-tag -->

            <div class="stakeholder-tag tag-container "id="puf-tab4C">
                <?php if (have_rows('stakeholder_tag')): //child group field
                        while (have_rows('stakeholder_tag')):
                            the_row(); ?>             
                        
                        <div class="desktop-image  ">
                                <?php $desktop_image = get_sub_field('desktop_image');
                            if (!empty($desktop_image)): ?>
                                    <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>
                        
                        <div class="tablet-image  ">
                                <?php $tablet_image = get_sub_field('tablet_image');
                            if (!empty($tablet_image)): ?>
                                    <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                        <div class="mobile-image  ">
                                <?php $mobile_image = get_sub_field('mobile_image');
                            if (!empty($mobile_image)): ?>
                                    <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                <?php
                            endif; ?>
                        </div>

                <?php
                        endwhile; ?>
            <?php
                    endif; ?>
            </div><!-- .workflow-tag -->    
            
         </div>

        </div> <!-- .people-familiar.duct-toggle --> 

        <?php
                endwhile; ?>
    <?php
            endif; ?>




    </div>

    </div> <!-- .duct-wrapper -->



    <?php
        endwhile;
        else return; // no posts found
        wp_reset_query();
      //  return html_entity_decode($out);

      return ob_get_clean();
    }
    add_shortcode('uct', 'use_case_query');
