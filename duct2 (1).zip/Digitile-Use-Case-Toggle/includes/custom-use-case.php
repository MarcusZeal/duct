<?php

    // ACF DUCT (Digitile Use Case Toggle)
    function use_case_query($atts, $content)    {

        ob_start();

        extract(shortcode_atts(array( // a few default values
            'id' => null,
            'posts_per_page' => '1',
            'caller_get_posts' => 1
        ) , $atts));

        $args = array(
            'post_type' => 'use_case',
            'numberposts' => - 1
        );

        if ($atts['id'])
        {
            $args['p'] = $atts['id'];
        }

        global $post;
        $posts = new WP_Query($args);
        $output = '';

        if ($posts->have_posts()) while ($posts->have_posts()):
            $posts->the_post();

    ?>



	<div class="duct-wrapper title-text-wrap">
		<div class="spacer">		</div>
		<div class="right-toggles title-text">
			 <?php the_title( '<h3>', '</h3>' ); ?>
		</div>
	</div>


<div class="duct-wrapper">

    <div class="left-toggles">
        <div class="tags-for-people-familiar-toggle left-toggle active" id="lt-tab1">
            <h3>Tags for People Familiar</h3>
            <p>Create a tagging scheme for people on your team, clients, or any stakeholder that’s familiar with tags</p>
        </div>
        <div class="tags-for-people-unfamiliar-toggle left-toggle"  id="lt-tab2">
            <h3>Tags for People Unfamiliar</h3>
            <p>Create a tagging scheme for people that haven’t joined the team yet, external stakeholders, or across departments</p>
        </div>
		
		
		<div class="custom-select-wrapper duct-mobile-menu">
			<div class="custom-select">
				<div class="custom-select__trigger"><span>Tags for People Familiar</span>
					<div class="arrow"></div>
				</div>
				<div class="custom-options">
					<span class="custom-option selected" data-value="lt-tab1C"  id="lt-tab1">Tags for People Familiar</span>
					<span class="custom-option" data-value="lt-tab2C"  id="lt-tab2">Tags for People Unfamiliar</span>
				</div>
			</div>
		</div>
		
		
    </div>

    <div class="right-toggles">

     <?php if (have_rows('tags_for_people_familiar')): //parent group field
        while (have_rows('tags_for_people_familiar')):
            the_row(); ?>

            <div class="people-familiar duct-toggle active" id="lt-tab1C"> 
                     
                <ul id="tabs" class="navbar">
                    <li class="tag-nav" ><a href="#pf-tab1C" class="url active">Content Tag</a></li>
                    <li class="tag-nav" ><a href="#pf-tab2C" class="url">Category Tag</a></li>
                    <li class="tag-nav" ><a href="#pf-tab3C" class="url">Workflow Tag</a></li>
                    <li class="tag-nav" ><a href="#pf-tab4C" class="url">Stakeholder Tag</a></li>
                </ul>

                <div class="owl-carousel">
                    <div class="content-tag tag-container" data-hash="pf-tab1C">
                        <?php if (have_rows('content_tag')): //child group field
                            while (have_rows('content_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div><!-- .content-tag -->
                    <div class="category-tag tag-container" data-hash="pf-tab2C">
                        <?php if (have_rows('category_tag')): //child group field
                            while (have_rows('category_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                                
                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div><!-- .category-tag -->

                    <div class="workflow-tag tag-container" data-hash="pf-tab3C">
                        <?php if (have_rows('workflow_tag')): //child group field
                            while (have_rows('workflow_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                                
                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>                    
                    </div><!-- .workflow-tag -->

                    <div class="stakeholder-tag tag-container" data-hash="pf-tab4C">
                        <?php if (have_rows('stakeholder_tag')): //child group field
                            while (have_rows('stakeholder_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                                
                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div><!-- .workflow-tag -->   
                </div>  <!-- owl-carousel-->  
            </div> <!-- .people-familiar.duct-toggle --> 

        <?php endwhile; ?>                
     <?php endif; ?>

    
     <?php if (have_rows('tags_for_people_unfamiliar')): //parent group field
        while (have_rows('tags_for_people_unfamiliar')):
            the_row(); ?>

            <div class="people-unfamiliar duct-toggle" id="lt-tab2C"> 

            
                <ul id="tabs" class="navbar">
                    <li class="tag-nav" ><a href="#puf-tab1C" class="url">Content Tag</a></li>
                    <li class="tag-nav" ><a href="#puf-tab2C" class="url">Category Tag</a></li>
                    <li class="tag-nav" ><a href="#puf-tab3C" class="url">Workflow Tag</a></li>
                    <li class="tag-nav" ><a href="#puf-tab4C" class="url">Stakeholder Tag</a></li>
                </ul>

                <div class="owl-carousel">
                    <div class="content-tag tag-container" data-hash="puf-tab1C">
                        <?php if (have_rows('content_tag')): //child group field
                            while (have_rows('content_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div><!-- .content-tag -->
                    <div class="category-tag tag-container" data-hash="puf-tab2C">
                        <?php if (have_rows('category_tag')): //child group field
                            while (have_rows('category_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                                
                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div><!-- .category-tag -->

                    <div class="workflow-tag tag-container" data-hash="puf-tab3C">
                        <?php if (have_rows('workflow_tag')): //child group field
                            while (have_rows('workflow_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                                
                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>                    
                    </div><!-- .workflow-tag -->

                    <div class="stakeholder-tag tag-container" data-hash="puf-tab4C">
                        <?php if (have_rows('stakeholder_tag')): //child group field
                            while (have_rows('stakeholder_tag')):
                                the_row(); ?>             
                            
                                <div class="desktop-image">
                                        <?php $desktop_image = get_sub_field('desktop_image');
                                if (!empty($desktop_image)): ?>
                                            <img src="<?php echo esc_url($desktop_image['url']); ?>" alt="<?php echo esc_attr($desktop_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>
                                
                                <div class="tablet-image">
                                        <?php $tablet_image = get_sub_field('tablet_image');
                                if (!empty($tablet_image)): ?>
                                            <img src="<?php echo esc_url($tablet_image['url']); ?>" alt="<?php echo esc_attr($tablet_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                                <div class="mobile-image">
                                        <?php $mobile_image = get_sub_field('mobile_image');
                                if (!empty($mobile_image)): ?>
                                            <img src="<?php echo esc_url($mobile_image['url']); ?>" alt="<?php echo esc_attr($mobile_image['alt']); ?>" />
                                        <?php
                                endif; ?>
                                </div>

                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div><!-- .workflow-tag -->   
                </div>  <!-- owl-carousel-->  
            </div> <!-- .people-unfamiliar.duct-toggle --> 

        <?php endwhile; ?>                
     <?php endif; ?>








    </div> <!-- right-toggles -->
</div> <!-- .duct-wrapper -->



    <?php
        endwhile;
        else return; // no posts found
        wp_reset_query();
      //  return html_entity_decode($out);

      return ob_get_clean();
    }
    add_shortcode('uct', 'use_case_query');
